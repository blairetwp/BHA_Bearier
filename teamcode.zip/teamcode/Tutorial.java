package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorController;

public class Tutorial extends OpMode {

    private DcMotorController dc_drive_controller;

    private DcMotor leftDrive;
    private DcMotor rightDrive;

    @Override
    public void init() {
        dc_drive_controller = hardwareMap.dcMotorController.get("drive_controller");
        leftDrive = hardwareMap.dcMotor.get("left_drive");
        rightDrive = hardwareMap.dcMotor.get("right_drive");
    }

    @Override
    public void loop() {
        if(gamepad1.a) {
            leftDrive.setPower(.5);
            rightDrive.setPower(.5);
        } else {
            leftDrive.setPower(0);
            rightDrive.setPower(0);
        }

    }

    @Override
    public void stop() {

    }

}